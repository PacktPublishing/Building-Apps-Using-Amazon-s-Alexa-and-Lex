var AWS = require('aws-sdk')

exports.handler = (event, context, callback) => {

	try {
		if (event.session.new) {
			console.log("NEW SESSION");
			onSessionStarted(event.request.requestId);
		}

		switch (event.request.type) {
			case "LaunchRequest":
				console.log("LAUNCH REQUEST");
	            onLaunch(event.request.requestId, callback)
				break;
			case "IntentRequest":
				console.log("INTENT REQUEST");
	            onIntent(event.request, event.session, callback);
				break;
			case "SessionEndedRequest":
				onSessionEnded(event.request.requestId)
				console.log("SESSION END REQUEST");
				break;
			default:
				context.fail("INVALID REQUEST TYPE:" + event.request.type);
		}
	} catch (error) {
		context.fail("Exception: " + error);
	}
};

function onSessionStarted(requestId) {
	console.log('In function onSessionStarted: ' + requestId);
}

function onLaunch(requestId, callback) {
	console.log('In function onLaunch: ' + requestId);

	handleWelcomeResponse(callback);
}

function onIntent(request, session, callback) {
	const intentName = request.intent.name;

	console.log('In function onIntent: ' + intentName);

	if (intentName === 'AddStock') {
		addStock(request, session, callback);
	} else if (intentName === 'RemoveStock') {
		removeStock(request, session, callback);
	} else if (intentName === 'ListStocks') {
		listStocks(request, session, callback);
	} else if (intentName === "AMAZON.HelpIntent") {
		handleWelcomeResponse(callback);
	} else if (intentName === "AMAZON.StopIntent" || intentName === "AMAZON.CancelIntent") {
		handleGoodbyeResponse(callback);
	} else {
		throw new Error("Could not identify indent: " + intent.name);
	}
}


function addStock(request, session, callback) {
	var userId = session.user.userId;
	var stockName = request.intent.slots.StockName.value;

	console.log('In function addStock for user: ' + userId + ' stock name: ' + stockName);

	docClient = new AWS.DynamoDB.DocumentClient();
	var params = {
		TableName: "StockList",
		Key: {'userId': userId},
		UpdateExpression: "ADD #StockName :name",
		ExpressionAttributeNames: {
			"#StockName": "Stocks"
		},
		ExpressionAttributeValues: {
			":name": docClient.createSet([stockName])
		},
		ReturnValues: "ALL_NEW"
	};

	docClient.update(params, function(err, data){
		if (err) {
			console.error("Unable to add stock: " + JSON.stringify(data));
		} else {
			console.log("Added stock successfully: " + stockName);
			
			const title = "Added Stock";
			const speechOutput = stockName + " added to stock list";
		
			const speechletResponse = buildSpeechletResponse(title, speechOutput, false);

			callback(null, generateResponse(speechletResponse, {}));
		}
	});
}

function removeStock(request, session, callback) {
	var userId = session.user.userId;
	var stockName = request.intent.slots.StockName.value;

	console.log('In function removeStock for user: ' + userId + ' stock name: ' + stockName);

	docClient = new AWS.DynamoDB.DocumentClient();
	var params = {
		TableName: "StockList",
		Key: {'userId': userId},
		UpdateExpression: "DELETE #StockName :name",
		ExpressionAttributeNames: {
			"#StockName": "Stocks"
		},
		ExpressionAttributeValues: {
			":name": docClient.createSet([stockName])
		},
		ReturnValues: "ALL_NEW"
	};

	docClient.update(params, function(err, data){
		if (err) {
			console.error("Unable to remove stock: " + JSON.stringify(data));
		} else {
			console.log("Removed stock successfully: " + stockName);
			
			const title = "Removed Stock";
			const speechOutput = stockName + " removed from stock list";
		
			const speechletResponse = buildSpeechletResponse(title, speechOutput, false);

			callback(null, generateResponse(speechletResponse, {}));
		}
	});
}

function listStocks(request, session, callback) {
	var userId = session.user.userId;

	console.log('In function listStocks for user: ' + userId);

	docClient = new AWS.DynamoDB.DocumentClient();
	var params = {
		TableName: "StockList",
		Key: {'userId': userId}
	};


	docClient.get(params, function(err, data) {

		if (err) {
			console.error("Unable to get stocks: " + JSON.stringify(data));
		} else {
			console.log("Got stocks successfully");
			
			const title = "List Stocks";
			var speechOutput = JSON.stringify(data);
			if (data.Item.Stocks !== 'undefined') {
				speechOutput = "Your favorite stocks are ";
				for (var i in data.Item.Stocks.values) {
					stockName = data.Item.Stocks.values[i];
					speechOutput += ", " + stockName;
				}
			} else {
				speechOutput = "There are no stocks in your stock list.";
			}
		
			const speechletResponse = buildSpeechletResponse(title, speechOutput, false);

			callback(null, generateResponse(speechletResponse, {}));
 		}
	});
}

function onSessionEnded(requestId) {
	console.log('In function onSessionEnded: ' + requestId);
}

// Invoked by the session launch as well as the help intent
function handleWelcomeResponse(callback) {
	console.log('In function handleWelcomeResponse');

	const title = "Welcome";
	const speechOutput = "Welcome to my stock list. " + 
		"You can say add stock, remove stock or list stocks.";

	const speechletResponse = buildSpeechletResponse(title, speechOutput, false);	
	const sessionAttributes = {};

	callback(null, generateResponse(speechletResponse, sessionAttributes));
}

function handleGoodbyeResponse(callback) {
	console.log('In function handleGoodbyeResponse');

	const title = "Goodbye";
	const speechOutput = "Thank you for trying the Stock Tracker Dialog. Have a nice day! ";

	const speechletResponse = buildSpeechletResponse(title, speechOutput, true);	
	const sessionAttributes = {};

	callback(null, generateResponse(speechletResponse, sessionAttributes));
}


buildSpeechletResponse = (title, outputText, shouldEndSession) => {
	return {
		outputSpeech: {
			type: "PlainText",
			text: outputText
		},
		card: {
			type: "Simple",
			title: title,
			content: outputText
		},
		shouldEndSession: shouldEndSession
	};
}


generateResponse = (speechletResponse, sessionAttributes) => {

	return {
		version: "1.0",
		sessionAttributes: sessionAttributes,
		response: speechletResponse
	};
}
